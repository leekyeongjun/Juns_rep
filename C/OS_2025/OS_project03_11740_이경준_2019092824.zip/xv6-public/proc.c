#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

#define thread_t struct proc*

struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

static struct proc *initproc;

int nextpid = 1;
extern void forkret(void);
extern void trapret(void);

static void wakeup1(void *chan);

void
pinit(void)
{
  initlock(&ptable.lock, "ptable");
}

// Must be called with interrupts disabled
int
cpuid() {
  return mycpu()-cpus;
}

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu*
mycpu(void)
{
  int apicid, i;
  
  if(readeflags()&FL_IF)
    panic("mycpu called with interrupts enabled\n");
  
  apicid = lapicid();
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i) {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}

// Disable interrupts so that we are not rescheduled
// while reading proc from the cpu structure
struct proc*
myproc(void) {
  struct cpu *c;
  struct proc *p;
  pushcli();
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

//PAGEBREAK: 32
// Look in the process table for an UNUSED proc.
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
  struct proc *p; // 새롭게 리턴할 프로세스 구조체, 초기 State = Unused
  char *sp; // 스택 포인터

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == UNUSED) // 새로 만든 구조체 발견
      goto found;

  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO; // Unused -> Embryo
  p->pid = nextpid++; // pid 하나 증가, nextpid는 proc.c에서 전역변수로 정의되어 있음.
  p->tnum = 0;
  p->tid = 0;

  release(&ptable.lock);

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
    p->state = UNUSED; // alloc 실패하면 다시 Unused로 바꿈
    return 0;
  }
  sp = p->kstack + KSTACKSIZE; // 스택 포인터기준 KSTACKSIZE(4096)만큼 공간 확보

  /*
  sp --------------- <- sp + 4096
     (비어있음)
     --------------- <- kstack
  */

  // Leave room for trap frame.
  sp -= sizeof *p->tf;

  /*
     --------------- <- sp + 4096
     (비어있음)
  sp --------------- <- sp - sizeof trapframe (p->tf)
     (트랩 프레임 공간)
     --------------- <- kstack
  */

  p->tf = (struct trapframe*)sp;

  /*
     --------------- <- sp + 4096
     ss
     esp
     ...
     ebp
     esi
     edi
  sp --------------- <- sp - sizeof trapframe (p->tf)

     --------------- <- kstack
  */

  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4; // 1바이트
  *(uint*)sp = (uint)trapret;

  /*
     --------------- <- sp + 4096
     ss
     esp
     ...
     ebp
     esi
     edi
     --------------- <- tf
     addr of trapret
  sp ---------------

     --------------- <- kstack
  */

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);

  /*
     --------------- <- sp + 4096
     ss
     esp
     ...
     ebp
     esi
     edi
     --------------- <- tf
     addr of trapret
     ---------------
     eip (0)
     ebp (0)
     ebx (0)
     esi (0)
     edi (0)
  sp --------------- <- context
     --------------- <- kstack
  */

  p->context->eip = (uint)forkret;

  /*
     --------------- <- sp + 4096
     ss
     esp
     ...
     ebp
     esi
     edi
     --------------- <- tf
     addr of trapret
     ---------------
     addr of forkret
     ebp (0)
     ebx (0)
     esi (0)
     edi (0)
  sp --------------- <- context
     --------------- <- kstack
  */
  return p;
}

//PAGEBREAK: 32
// Set up first user process.
void
userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();
  
  initproc = p;
  if((p->pgdir = setupkvm()) == 0)
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
  p->sz = PGSIZE;
  memset(p->tf, 0, sizeof(*p->tf));
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0;  // beginning of initcode.S

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  // this assignment to p->state lets other cores
  // run this process. the acquire forces the above
  // writes to be visible, and the lock is also needed
  // because the assignment might not be atomic.
  acquire(&ptable.lock);

  p->state = RUNNABLE;

  release(&ptable.lock);
}

// Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint sz;
  struct proc *curproc = myproc();

  sz = curproc->sz;
  if(n > 0){
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  } else if(n < 0){
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  curproc->sz = sz;
  switchuvm(curproc);
  return 0;
}

// Create a new process copying p as the parent.
// Sets up stack to return as if from system call.
// Caller must set state of returned proc to RUNNABLE.
int
fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // 현재 np 상태
  /*

     --------------- <- sp + 4096
     ss
     esp
     ...
     eax
     ecx
     edx
     ebx
     oesp
     ebp
     esi
     edi
     --------------- <- tf
     addr of trapret
     ---------------
     addr of forkret
     ebp (0)
     ebx (0)
     esi (0)
     edi (0)
  sp --------------- <- context
     --------------- <- kstack

  */
  // Copy process state from proc.
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){ // pgdir 주소값에서 sz만큼 복사
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;

  // Clear %eax so that fork returns 0 in the child.
  np->tf->eax = 0;

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  pid = np->pid;

  acquire(&ptable.lock);

  np->state = RUNNABLE;

  release(&ptable.lock);

  return pid;
}

// 스레드를 만들어서 주소값을 리턴해주는 함수
int
tcreate(thread_t thread, void *(*start_routine)(void*), void *arg, void* threadUserStack){
  struct proc* ct;
  struct proc* curproc = myproc();
  // Allocate process.
  if((ct = allocproc()) == 0){
    return -1;
  }

  /* 현재 thread 상태

     --------------- <- sp + 4096
     ss
     esp
     ...
     eax
     ecx
     edx
     ebx
     oesp
     ebp
     esi
     edi
     --------------- <- tf
     addr of trapret
     ---------------
     addr of forkret
     ebp (0)
     ebx (0)
     esi (0)
     edi (0)
     --------------- <- context
     --------------- <- kstack
  */

// 스레드는 부모 프로세스와 페이지 테이블을 공유함
  ct->pgdir = curproc->pgdir;
  ct->sz = curproc->sz;  
  ct->parent = curproc->parent;
  *ct->tf = *curproc->tf;
  ct->tf->eax = 0;

  int i;
  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      ct->ofile[i] = filedup(curproc->ofile[i]);
  ct->cwd = idup(curproc->cwd);

  safestrcpy(ct->name, curproc->name, sizeof(curproc->name));

  
// 스레드는 호출 이후 포인터를 넘겨준 함수를 실행해야함. 그리고 실행 뒤에 사라짐.
// 이제 스레드만의 유저스택에 함수 실행을 위한 정보를 만들어야 한다.
// 근데 이 유저스택을 커널이 만들면 안된다. 유저가 프로세스 딴에서 만들어서 해당 메모리 영역을 사용하라고 넘겨주는 형태여야 한다.
// 따라서 tcreate 함수는 유저스택으로 사용할수 있는 페이지사이즈 만큼의 메모리를 할당받았다고 가정하고, 해당 메모리의 주소값을 유저스택의 시작으로 잡는다 (threadUserStack).

  void* tstackWorker = threadUserStack;
  
// threadUserStack을 훑으면서 함수 실행에 필요한 자료를 채워넣는 역할
/* 프로세스에서, 유저스택의 구조는 다음과 같다.

Ustack    -----------------
(PGSIZE)       
          ----------------- 
(PGSIZE)   (Guard Page)
          -----------------

해당 코드를 통해 스레드의 스택 영역을 추가한다. 즉 다음과 같은 모양새가 될 것.


Tstack    -----------------
(PGSIZE)       
          -----------------
(PGSIZE)    (Guard Page)
Ustack    -----------------
(PGSIZE)       
          ----------------- 
(PGSIZE)    (Guard Page)
          -----------------

*/
  tstackWorker += PGSIZE;

/*
  tstackWorker --------------
    (pgsize)
  th_Userstack --------------
*/

  tstackWorker -= sizeof(void*);
  void* argadd = tstackWorker;
  *(uint*)argadd = (uint)arg;

/*
               --------------
 (sizeof void*) add of add of arg
  tstackWorker --------------
    (pgsize)
  th_Userstack --------------
*/

  tstackWorker -= sizeof(void*);
  void* retadd = tstackWorker;
  *(uint*)retadd = 0xFFFFFFFF; // fake return address

/*
               --------------
 (sizeof void*) add of add of arg
  tstackWorker --------------
(size of void*) return address
  tstackWorker --------------
    (pgsize)
  th_Userstack --------------
*/

  ct -> tf -> esp = (uint)threadUserStack;
  ct -> tstack = threadUserStack; // 나중에 Stack영역 free할때 쓸것.
  ct -> tf -> esp += PGSIZE - 2 * sizeof(void*);
  ct -> tf -> ebp = ct -> tf -> esp;
  ct -> tf -> eip = (uint) start_routine;
  ct -> tf -> eax = 0;

/*
               --------------
 (sizeof void*) add of add of arg
  tstackWorker --------------
(size of void*) return address     <- esp / ebp
  tstackWorker -------------- 
    (pgsize)
  th_Userstack --------------      <- tstack
*/

  acquire(&ptable.lock);
  curproc->tnum ++;
  ct->tid = curproc->tnum;
  ct->state = RUNNABLE;
  thread = ct;
  release(&ptable.lock);
  return thread;

}

int
tjoin(thread_t thread, void** retval)
{
// 그냥 프로세스와, 스레드를 어떻게 구분할 수 있는가?
// 프로세스 : pid가 있고, tid = 0임.
// 스레드 : pid가 부모 pid와 같고, tid가 0이상임.

// 무엇을 free해야 하는가? -> thread가 가지고 있는 stack영역을 free해야함.
// 즉, thread->tstack영역을 free해야함.

  struct proc *p;
  struct proc *curproc = myproc();
  struct proc *masterThread;
  struct proc *curthread;

  acquire(&ptable.lock);
  while(1){
    // 현재 스레드가 유효한지 검사
    int valid = 0;
    for(p = ptable.proc; p<&ptable.proc[NPROC]; p++){
      if(thread->pid == p->pid && thread->tid == p->tid){
        curthread = p;
      }
    }

    if(!curthread) valid = 1;
    if(curthread->pid != curproc->pid) valid = 1;

    if(valid != 0){
      release(&ptable.lock);
      return -1;
    }

    // 부모 프로세스 찾기
    for(p = ptable.proc; p<&ptable.proc[NPROC]; p++){
      if(curproc->pid == p->pid && p->tid == 0){
        masterThread = p;
      }
    }
    if(!masterThread || masterThread->killed) {
      release(&ptable.lock);
      return -1;
    }

    // 실행이 종료된 자식 프로세스 free
    if(curthread->state == ZOMBIE){
      int threadpid = curthread->pid;
      kfree(curthread->kstack);
      curthread->kstack = 0;
      retval = curthread->tstack;
      curthread->tstack = 0;
      curthread->state = UNUSED;
      release(&ptable.lock);
      return threadpid;
    }
    sleep(curproc, &ptable.lock);

  }
}
// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait() to find out it exited.
void
exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if(curproc == initproc)
    panic("init exiting");

  // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd]){
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  } 

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  acquire(&ptable.lock);

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

  // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->parent == curproc){
      p->parent = initproc;
      if(p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
wait(void)
{
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();
  
  acquire(&ptable.lock);
  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc)
        continue;
      havekids = 1;
      if(p->state == ZOMBIE){
        // Found one.
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    }

    // Wait for children to exit.  (See wakeup1 call in proc_exit.)
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
  }
}

//PAGEBREAK: 42
// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run
//  - swtch to start running that process
//  - eventually that process transfers control
//      via swtch back to the scheduler.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  c->proc = 0;
  
  for(;;){
    // Enable interrupts on this processor.
    sti();

    // Loop over process table looking for process to run.
    acquire(&ptable.lock);
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->state != RUNNABLE)
        continue;

      // Switch to chosen process.  It is the process's job
      // to release ptable.lock and then reacquire it
      // before jumping back to us.
      c->proc = p;
      switchuvm(p);
      p->state = RUNNING;

      swtch(&(c->scheduler), p->context);
      switchkvm();

      // Process is done running for now.
      // It should have changed its p->state before coming back.
      c->proc = 0;
    }
    release(&ptable.lock);

  }
}

// Enter scheduler.  Must hold only ptable.lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->ncli, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&ptable.lock))
    panic("sched ptable.lock");
  if(mycpu()->ncli != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(readeflags()&FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;
  swtch(&p->context, mycpu()->scheduler);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  acquire(&ptable.lock);  //DOC: yieldlock
  myproc()->state = RUNNABLE;
  sched();
  release(&ptable.lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);

  if (first) {
    // Some initialization functions must be run in the context
    // of a regular process (e.g., they call sleep), and thus cannot
    // be run from main().
    first = 0;
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  if(p == 0)
    panic("sleep");

  if(lk == 0)
    panic("sleep without lk");

  // Must acquire ptable.lock in order to
  // change p->state and then call sched.
  // Once we hold ptable.lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup runs with ptable.lock locked),
  // so it's okay to release lk.
  if(lk != &ptable.lock){  //DOC: sleeplock0
    acquire(&ptable.lock);  //DOC: sleeplock1
    release(lk);
  }
  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  if(lk != &ptable.lock){  //DOC: sleeplock2
    release(&ptable.lock);
    acquire(lk);
  }
}

//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
  struct proc *p;

  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
      p->killed = 1;
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

//PAGEBREAK: 36
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [EMBRYO]    "embryo",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}
